import pandas as pd
from src.ingestion.etl import transform, validate


def test_transform_hashes_customer_name():
    df = pd.DataFrame({
        "shipment_id": ["1"] * 5000,
        "customer_name": ["Alice"] * 5000,
        "customer_address": ["Demo Address 1"] * 5000,
        "hub_location": ["HUB_US"] * 5000,
        "service_level": ["Express_Worldwide"] * 5000,
        "transit_duration_hours": [10] * 5000,
        "weather_severity": [0.2] * 5000,
        "traffic_density": [0.3] * 5000,
        "package_weight_kg": [2] * 5000,
        "route_distance_km": [500] * 5000,
    })
    out = transform(df)
    assert out.loc[0, "customer_name"] != "Alice"
    assert out.loc[0, "customer_address"] == "REGIONAL_ZONE"
    validate(out)
