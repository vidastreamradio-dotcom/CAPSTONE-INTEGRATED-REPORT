"""CI helper matching the capstone recall gate."""
import argparse
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--min-recall", type=float, default=0.85)
    args = parser.parse_args()

    metrics_file = Path("artifacts/metrics.json")
    if not metrics_file.exists():
        raise SystemExit("metrics.json not found; train the model first.")

    payload = json.loads(metrics_file.read_text())
    selected = payload["selected_model"]
    recall = payload["models"][selected]["recall"]
    print(f"Selected model={selected}; recall={recall:.4f}")

    if recall < args.min_recall:
        raise SystemExit(f"Recall gate failed: {recall:.4f} < {args.min_recall:.4f}")


if __name__ == "__main__":
    main()
