# Source

This repository was assembled from the uploaded `BAN6800 Business Analytics Capstone Integrated Report`.

The report describes the DHL Express decision-support use case, a 5,500-record historical dataset,
XGBoost modeling, SHAP/LIME/DiCE explainability, Fairlearn auditing, FastAPI, Streamlit, Airflow,
Docker, GitHub Actions, monitoring, and governance controls.

The underlying enterprise dataset was not part of the uploaded document. Therefore this repository
uses synthetic/demo shipment data for runnable development and testing.
