# Technical Governance

## Governance principles

### Human autonomy
Recommendations remain advisory. Operational personnel retain decision authority.

### Privacy by design
Customer identifiers are salted-hashed and exact addresses are generalized before model use.

### Algorithmic equity
Performance and error rates are monitored across regional hubs and service categories.

### Actionable explainability
Critical predictions should expose operational drivers such as weather severity and transit buffer loss.

### Auditability
Production systems should retain inference metadata, explanation values, model versions, and dispatcher overrides in controlled logs.

## Monitoring

- Weekly KS tests for selected operational features
- Drift flag when `p < 0.05`
- Retraining when ROC-AUC `< 0.88` or Recall `< 0.85`
- Critical alert when regional disparity exceeds 15% or Recall remains below 0.80 for two consecutive days

## Incident response

1. Identify severity
2. Activate fallback rule-based routing
3. Investigate root cause
4. Revalidate model and governance controls
5. Obtain required sign-off
6. Archive/decommission model and purge PII logs according to retention policy
