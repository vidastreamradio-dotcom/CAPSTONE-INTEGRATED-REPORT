# Model Card

## Model details

- **Project:** BAN6800 Business Analytics Capstone
- **Developer:** Akpevwe Peters, Student Lead Analyst, Nexford University
- **Architecture:** XGBoost classifier
- **Capstone configuration:** `n_estimators=300`, `max_depth=6`, `learning_rate=0.05`, `scale_pos_weight=4.5`
- **Intended version:** v2.4-fairlearn
- **Repository:** `akpevwepeters1010-code/dhl-logistics-analytics`

## Intended use

Predict shipment SLA delay risk 2–6 hours before last-mile dispatch to support human dispatcher decisions.

## Out of scope

- Autonomous fleet dispatch
- Automated courier penalty allocation
- Individual driver performance evaluation
- Any employment decision

## Reported capstone evaluation

The uploaded report states:
- Accuracy: 94.1%
- Precision: 84.2%
- Recall: 89.4%
- F1: 0.867
- ROC-AUC: 0.958

These figures are **reported in the capstone document**. They are not a claim that this newly generated repository reproduces the same results without the original underlying dataset and exact training environment.

## Limitations

The report notes that the system cannot account for unrecorded post-scan events such as driver breakdowns and requires regular drift monitoring.
