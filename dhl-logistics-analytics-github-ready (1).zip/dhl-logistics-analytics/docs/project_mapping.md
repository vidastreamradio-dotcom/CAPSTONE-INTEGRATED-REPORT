# Capstone-to-Repository Mapping

| Capstone report section | Repository artifact |
|---|---|
| Business problem | `README.md` |
| Ethical AI charter | `docs/algorithmic_impact_assessment.md` |
| Data pipeline | `src/ingestion/`, `dags/` |
| Data quality | `src/ingestion/etl.py`, tests |
| Modeling | `src/models/train.py` |
| XAI | `src/explainability/shap_explainer.py` |
| Fairness | `src/fairness/audit.py` |
| Model card | `docs/model_card.md` |
| API | `app/main.py` |
| Dashboard | `app/dashboard.py` |
| CI/CD | `.github/workflows/ci_cd.yml` |
| Monitoring | `src/monitoring/drift.py` |
| Governance | `docs/governance.md` |
