# Data Dictionary

| Field | Type | Meaning | Model use |
|---|---|---|---|
| `shipment_id` | string | Shipment identifier | Traceability only |
| `customer_name` | string | Customer identifier before hashing | Not a model feature |
| `customer_address` | string | Address before generalization | Not a model feature |
| `hub_location` | category | Destination sorting hub | Yes |
| `service_level` | category | Service tier | Yes |
| `transit_duration_hours` | float | Upstream transit duration | Yes |
| `weather_severity` | float | Normalized weather severity, 0–1 | Yes |
| `traffic_density` | float | Normalized traffic density, 0–1 | Yes |
| `package_weight_kg` | float | Package weight | Yes |
| `route_distance_km` | float | Route distance | Yes |
| `delayed` | integer | Synthetic/demo target: 1 delayed, 0 on-time | Target |

### Leakage controls

The capstone excludes post-prediction variables such as actual final delivery timestamps, driver tip records, post-transit scans, and customer complaint logs from the feature set.
