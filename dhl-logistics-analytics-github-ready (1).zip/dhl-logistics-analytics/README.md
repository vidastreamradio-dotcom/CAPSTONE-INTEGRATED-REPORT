# DHL Logistics Analytics

> BAN6800 Business Analytics Capstone — Executive Decision-Support & Technical Governance

A production-oriented reference implementation of an early-warning system for shipment SLA delay risk. The system predicts whether an inbound shipment is at risk of an SLA breach **2–6 hours before last-mile dispatch**, provides local SHAP explanations, applies fairness auditing/mitigation, and exposes predictions through FastAPI and Streamlit.

**Important:** The capstone report describes 5,500 historical enterprise shipment records, but those raw records were not included with the uploaded report. This repository therefore includes a **synthetic/demo data generator** so the project is runnable without fabricating or exposing real DHL operational data. Replace the generated data with authorized enterprise data before production use.

## Capstone alignment

| Capability | Implementation |
|---|---|
| Data ingestion | Python ETL + Airflow DAG |
| Privacy | Salted SHA-256 customer identifier hashing; address generalization |
| Data quality | Validation module and Great Expectations-compatible checks |
| Modeling | Logistic Regression, Random Forest, XGBoost |
| Class imbalance | `scale_pos_weight=4.5` |
| Explainability | SHAP; optional LIME/DiCE integrations |
| Fairness | Fairlearn Equalized Odds / ExponentiatedGradient |
| API | FastAPI `/predict`, `/health` |
| Dashboard | Streamlit operational risk queue |
| Monitoring | KS drift checks + retraining thresholds |
| Governance | Model card, AIA, incident/decommissioning plan |
| CI/CD | GitHub Actions |
| Deployment | Docker / Docker Compose |
| Tests | Pytest |

## Architecture

```text
                 +----------------------+
                 | Raw shipment scans   |
                 | CSV / S3 in prod     |
                 +----------+-----------+
                            |
                            v
                 +----------------------+
                 | Privacy + ETL        |
                 | hash / clean / cap   |
                 +----------+-----------+
                            |
                            v
                 +----------------------+
                 | Quality gates        |
                 | validation           |
                 +----------+-----------+
                            |
                            v
                 +----------------------+
                 | Feature table        |
                 | PostgreSQL in prod   |
                 +----------+-----------+
                            |
                  +---------+----------+
                  |                    |
                  v                    v
          +---------------+     +---------------+
          | XGBoost       |     | Fairness      |
          | training      |     | audit         |
          +-------+-------+     +-------+-------+
                  |                     |
                  +----------+----------+
                             v
                    +----------------+
                    | Model registry |
                    | / artifacts     |
                    +-------+--------+
                            |
                +-----------+-----------+
                |                       |
                v                       v
        +---------------+       +---------------+
        | FastAPI       |       | Streamlit     |
        | /predict      |       | risk dashboard|
        +---------------+       +---------------+
                |
                v
        +-------------------+
        | Monitoring / logs |
        | drift / retrain   |
        +-------------------+
```

## Quick start

### 1. Create an environment

```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS/Linux
source .venv/bin/activate

pip install -r requirements.txt
```

### 2. Generate demo data

```bash
python -m src.ingestion.generate_demo_data --rows 5500 --output data/raw/shipments.csv
```

### 3. Run the ETL

```bash
python -m src.ingestion.etl --input data/raw/shipments.csv --output data/processed/shipments_clean.csv
```

### 4. Train the model

```bash
python -m src.models.train
```

The trained model is written to `artifacts/model.joblib`.

### 5. Start the API

```bash
uvicorn app.main:app --reload --port 8000
```

Open `http://localhost:8000/docs`.

### 6. Start the dashboard

```bash
streamlit run app/dashboard.py
```

### 7. Run tests

```bash
pytest -q
```

## Example API request

```json
{
  "shipment_id": "DHL-DEMO-88392",
  "hub_location": "HUB_LATAM",
  "service_level": "Express_Worldwide",
  "transit_duration_hours": 14.2,
  "weather_severity": 0.82,
  "traffic_density": 0.75,
  "package_weight_kg": 4.5,
  "route_distance_km": 950
}
```

## Governance boundaries

The system is **decision support**, not autonomous dispatch. Human dispatchers retain authority over operational actions. The model must not be used for automated employment decisions, driver performance scoring, or customer eligibility decisions.

The capstone specifies monitoring and incident thresholds including:
- Recall target: `>= 0.85`
- ROC-AUC target: `>= 0.90`
- Retraining trigger: ROC-AUC `< 0.88` or Recall `< 0.85`
- Critical incident: disparity `> 15%` or Recall `< 0.80` for two consecutive days
- Fairness target: Disparate Impact Ratio within `0.80–1.25`

These are governance requirements from the capstone report, not guarantees of production performance.

## Repository layout

```text
dhl-logistics-analytics/
├── .github/workflows/ci_cd.yml
├── app/
│   ├── main.py
│   └── dashboard.py
├── dags/
│   └── dhl_express_etl_dag.py
├── data/
│   ├── raw/.gitkeep
│   └── processed/.gitkeep
├── docs/
│   ├── model_card.md
│   ├── data_dictionary.md
│   ├── algorithmic_impact_assessment.md
│   └── governance.md
├── src/
│   ├── ingestion/
│   ├── models/
│   ├── explainability/
│   ├── fairness/
│   └── monitoring/
├── tests/
├── Dockerfile
├── docker-compose.yml
├── requirements.txt
├── pyproject.toml
└── .gitignore
```

## Data privacy

Never commit production shipment records, customer names, addresses, tracking identifiers, API keys, credentials, or model logs containing sensitive information. See `.gitignore` and the governance documents.

## Academic provenance

This implementation is derived from the uploaded BAN6800 Business Analytics Capstone Integrated Report, including its stated architecture, metrics, governance principles, repository structure, API example, monitoring thresholds, and model-card requirements.
