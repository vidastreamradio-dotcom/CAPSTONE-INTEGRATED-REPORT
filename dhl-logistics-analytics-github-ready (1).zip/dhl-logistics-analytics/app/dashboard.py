"""Streamlit operational dashboard."""
from __future__ import annotations

from pathlib import Path
import json
import pandas as pd
import streamlit as st

st.set_page_config(page_title="DHL Operational Risk Dashboard", layout="wide")
st.title("DHL Express Operational Risk Dashboard")
st.caption("BAN6800 capstone reference implementation — synthetic/demo data")

data_path = Path("data/processed/shipments_clean.csv")
metrics_path = Path("artifacts/metrics.json")

if not data_path.exists():
    st.warning("No processed data found. Run the Quick Start commands in README.md.")
    st.stop()

df = pd.read_csv(data_path)
metrics = json.loads(metrics_path.read_text()) if metrics_path.exists() else {}

c1, c2, c3, c4 = st.columns(4)
c1.metric("Shipments", f"{len(df):,}")
c2.metric("Delayed", f"{int(df['delayed'].sum()):,}" if "delayed" in df else "N/A")
c3.metric("Recall", f"{metrics.get('models', {}).get(metrics.get('selected_model', ''), {}).get('recall', 0):.1%}")
c4.metric("Model", metrics.get("selected_model", "Not trained"))

st.subheader("Priority Risk Queue")
if "delayed" in df:
    # Demo queue uses operational risk proxy; production must use model probabilities.
    queue = df.sort_values(
        ["weather_severity", "traffic_density"], ascending=False
    ).head(20)
    st.dataframe(
        queue[
            [
                "shipment_id",
                "hub_location",
                "service_level",
                "weather_severity",
                "traffic_density",
                "transit_duration_hours",
            ]
        ],
        use_container_width=True,
    )

st.subheader("Operational Drivers")
st.bar_chart(
    df[["weather_severity", "traffic_density", "transit_duration_hours"]].mean()
)

st.info(
    "Human-in-the-loop control: dashboard outputs are advisory. Dispatchers validate "
    "operational context before taking action."
)
