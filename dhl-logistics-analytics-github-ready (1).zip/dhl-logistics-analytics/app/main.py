"""FastAPI inference service."""
from __future__ import annotations

import os
from pathlib import Path
import joblib
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

app = FastAPI(
    title="DHL Logistics Analytics API",
    version="0.1.0",
    description="Human-in-the-loop shipment SLA delay-risk decision support.",
)

MODEL_PATH = Path(os.getenv("MODEL_PATH", "artifacts/model.joblib"))
_model = None


class Shipment(BaseModel):
    shipment_id: str
    hub_location: str
    service_level: str
    transit_duration_hours: float = Field(ge=0)
    weather_severity: float = Field(ge=0, le=1)
    traffic_density: float = Field(ge=0, le=1)
    package_weight_kg: float = Field(ge=0)
    route_distance_km: float = Field(ge=0)


def get_model():
    global _model
    if _model is None and MODEL_PATH.exists():
        _model = joblib.load(MODEL_PATH)
    return _model


@app.get("/health")
def health():
    return {"status": "ok", "model_loaded": get_model() is not None}


@app.post("/predict")
def predict(shipment: Shipment):
    model = get_model()
    if model is None:
        raise HTTPException(
            status_code=503,
            detail="Model artifact not found. Generate data and train the model first.",
        )

    payload = shipment.model_dump()
    features = {k: v for k, v in payload.items() if k != "shipment_id"}
    import pandas as pd
    frame = pd.DataFrame([features])
    probability = float(model.predict_proba(frame)[:, 1][0])
    risk = "CRITICAL" if probability >= 0.70 else "ELEVATED" if probability >= 0.40 else "LOW"

    drivers = sorted(
        [
            ("weather_severity", shipment.weather_severity),
            ("traffic_density", shipment.traffic_density),
            ("transit_duration_hours", shipment.transit_duration_hours),
        ],
        key=lambda x: x[1],
        reverse=True,
    )[:2]

    action = (
        "Escalate for dispatcher review and consider dynamic re-routing."
        if risk == "CRITICAL"
        else "Review queue and operational context."
        if risk == "ELEVATED"
        else "Standard delivery workflow."
    )

    return {
        "shipment_id": shipment.shipment_id,
        "sla_delay_probability": round(probability, 3),
        "risk_category": risk,
        "recommended_action": action,
        "top_risk_drivers": {
            name: round(value, 3) for name, value in drivers
        },
        "model_version": "v2.4-fairlearn-compatible-demo",
        "human_review_required": True,
    }
