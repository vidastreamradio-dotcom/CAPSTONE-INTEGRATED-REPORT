# Security

Do not commit:
- real customer data
- tracking identifiers
- addresses
- credentials
- API keys
- production database dumps
- sensitive model logs

Report security issues privately to the repository owner rather than opening a public issue containing sensitive details.
