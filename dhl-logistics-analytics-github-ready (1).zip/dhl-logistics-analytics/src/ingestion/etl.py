"""Privacy-aware shipment ETL."""
from __future__ import annotations

import argparse
import hashlib
import os
from pathlib import Path
import pandas as pd


CORE_FIELDS = ["shipment_id", "hub_location", "service_level", "transit_duration_hours"]
FEATURES = [
    "transit_duration_hours",
    "weather_severity",
    "traffic_density",
    "package_weight_kg",
    "route_distance_km",
]


def salted_hash(value: str, salt: str) -> str:
    return hashlib.sha256(f"{salt}:{value}".encode("utf-8")).hexdigest()


def transform(df: pd.DataFrame, salt: str = "demo-development-salt") -> pd.DataFrame:
    out = df.copy()
    if "customer_name" in out:
        out["customer_name"] = out["customer_name"].astype(str).map(
            lambda x: salted_hash(x, salt)
        )
    if "customer_address" in out:
        out["customer_address"] = out["customer_address"].astype(str).str.replace(
            r"^Demo Address.*$", "REGIONAL_ZONE", regex=True
        )

    for col in FEATURES:
        if col in out:
            out[col] = pd.to_numeric(out[col], errors="coerce")
            out[col] = out[col].fillna(out[col].median())

    for col in ["weather_severity", "traffic_density"]:
        if col in out:
            out[col] = out[col].clip(0.0, 1.0)

    for col in ["transit_duration_hours", "package_weight_kg", "route_distance_km"]:
        if col in out:
            cap = out[col].quantile(0.995)
            out[col] = out[col].clip(upper=cap)

    return out


def validate(df: pd.DataFrame, min_rows: int = 5000) -> None:
    if len(df) < min_rows:
        raise ValueError(f"Quality gate failed: {len(df)} rows < {min_rows}")
    missing = [c for c in CORE_FIELDS if c not in df.columns]
    if missing:
        raise ValueError(f"Missing core fields: {missing}")
    if df[CORE_FIELDS].isna().any().any():
        raise ValueError("Quality gate failed: core fields contain nulls")
    for col in ["weather_severity", "traffic_density"]:
        if not df[col].between(0, 1).all():
            raise ValueError(f"Range check failed for {col}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    df = pd.read_csv(args.input)
    out = transform(df, salt=os.getenv("PII_HASH_SALT", "demo-development-salt"))
    validate(out)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    out.to_csv(args.output, index=False)
    print(f"ETL complete: {len(out)} records -> {args.output}")


if __name__ == "__main__":
    main()
