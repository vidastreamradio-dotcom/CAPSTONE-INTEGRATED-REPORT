"""Generate synthetic shipment telemetry for development/testing.

This is NOT a copy of DHL data. It exists because the capstone report does not
include the underlying 5,500-row dataset.
"""
from __future__ import annotations

import argparse
from pathlib import Path
import numpy as np
import pandas as pd


HUBS = ["HUB_US", "HUB_EU", "HUB_APAC", "HUB_LATAM"]
SERVICES = ["Express_Worldwide", "Same_Day", "Economy_Select"]


def generate(rows: int = 5500, seed: int = 42) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    hub = rng.choice(HUBS, rows, p=[0.42, 0.35, 0.15, 0.08])
    service = rng.choice(SERVICES, rows, p=[0.55, 0.25, 0.20])
    weather = rng.beta(2.2, 5.0, rows)
    traffic = rng.beta(2.0, 4.0, rows)
    transit = np.clip(rng.normal(12.0, 4.5, rows), 2, 30)
    weight = np.clip(rng.lognormal(1.2, 0.7, rows), 0.2, 50)
    distance = np.clip(rng.normal(850, 350, rows), 20, 2500)

    # Synthetic relationship designed for an imbalanced classification example.
    logit = (
        -4.0
        + 2.7 * weather
        + 2.2 * traffic
        + 0.10 * transit
        + 0.0007 * distance
        + 0.015 * weight
        + np.where(service == "Express_Worldwide", 0.25, 0.0)
        + np.where(hub == "HUB_LATAM", 0.35, 0.0)
    )
    p_delay = 1 / (1 + np.exp(-logit))
    delayed = rng.binomial(1, p_delay)

    customer = [f"DEMO-CUSTOMER-{i:06d}" for i in range(rows)]
    address = [f"Demo Address {i:05d}" for i in range(rows)]

    return pd.DataFrame({
        "shipment_id": [f"DHL-DEMO-{i:06d}" for i in range(rows)],
        "customer_name": customer,
        "customer_address": address,
        "hub_location": hub,
        "service_level": service,
        "transit_duration_hours": np.round(transit, 2),
        "weather_severity": np.round(weather, 4),
        "traffic_density": np.round(traffic, 4),
        "package_weight_kg": np.round(weight, 2),
        "route_distance_km": np.round(distance, 2),
        "delayed": delayed,
    })


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--rows", type=int, default=5500)
    parser.add_argument("--output", type=Path, default=Path("data/raw/shipments.csv"))
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    generate(args.rows).to_csv(args.output, index=False)
    print(f"Wrote synthetic demo dataset: {args.output}")


if __name__ == "__main__":
    main()
