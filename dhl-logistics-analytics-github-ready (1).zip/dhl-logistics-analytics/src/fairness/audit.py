"""Fairness audit utilities."""
from __future__ import annotations

import pandas as pd
from sklearn.metrics import confusion_matrix


def false_negative_rate(y_true, y_pred) -> float:
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    return float(fn / (fn + tp)) if (fn + tp) else 0.0


def regional_fnr(df: pd.DataFrame, group_col: str = "hub_location") -> pd.DataFrame:
    rows = []
    for group, part in df.groupby(group_col):
        rows.append({
            group_col: group,
            "sample_count": len(part),
            "fnr": false_negative_rate(part["delayed"], part["prediction"]),
        })
    return pd.DataFrame(rows)
