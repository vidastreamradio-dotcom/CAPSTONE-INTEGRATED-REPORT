"""Monitoring and retraining threshold helpers."""
from __future__ import annotations

from scipy.stats import ks_2samp


def ks_drift(reference, current, alpha: float = 0.05) -> dict:
    statistic, p_value = ks_2samp(reference, current)
    return {
        "ks_statistic": float(statistic),
        "p_value": float(p_value),
        "drift_detected": bool(p_value < alpha),
    }


def needs_retraining(roc_auc: float, recall: float) -> bool:
    return roc_auc < 0.88 or recall < 0.85
