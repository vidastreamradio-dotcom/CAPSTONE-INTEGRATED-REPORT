"""Local/global explanation helpers."""
from __future__ import annotations

from pathlib import Path
import joblib
import pandas as pd


def explain(row: dict, model_path: str = "artifacts/model.joblib") -> dict:
    """Return a simple local explanation.

    The production implementation should persist the exact SHAP values generated
    by the fitted model. This lightweight function returns the highest-risk
    operational inputs so the API remains usable without a model-specific SHAP
    dependency at inference time.
    """
    model = joblib.load(Path(model_path))
    frame = pd.DataFrame([row])
    probability = float(model.predict_proba(frame)[:, 1][0])

    drivers = {
        "weather_severity": float(row["weather_severity"]),
        "traffic_density": float(row["traffic_density"]),
        "transit_duration_hours": float(row["transit_duration_hours"]),
    }
    top = sorted(drivers.items(), key=lambda kv: kv[1], reverse=True)[:2]
    return {
        "probability": probability,
        "top_risk_drivers": [{"feature": k, "value": v} for k, v in top],
    }
