"""Train and persist the capstone classification model."""
from __future__ import annotations

from pathlib import Path
import json
import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from sklearn.model_selection import train_test_split
from xgboost import XGBClassifier

FEATURES = [
    "hub_location",
    "service_level",
    "transit_duration_hours",
    "weather_severity",
    "traffic_density",
    "package_weight_kg",
    "route_distance_km",
]
TARGET = "delayed"
ARTIFACTS = Path("artifacts")


def build_preprocessor() -> ColumnTransformer:
    categorical = ["hub_location", "service_level"]
    numeric = [c for c in FEATURES if c not in categorical]
    return ColumnTransformer(
        [
            ("cat", OneHotEncoder(handle_unknown="ignore"), categorical),
            ("num", SimpleImputer(strategy="median"), numeric),
        ]
    )


def metrics(y_true, pred, proba) -> dict:
    return {
        "accuracy": accuracy_score(y_true, pred),
        "precision": precision_score(y_true, pred, zero_division=0),
        "recall": recall_score(y_true, pred, zero_division=0),
        "f1": f1_score(y_true, pred, zero_division=0),
        "roc_auc": roc_auc_score(y_true, proba),
    }


def main() -> None:
    data_path = Path("data/processed/shipments_clean.csv")
    ARTIFACTS.mkdir(exist_ok=True)
    df = pd.read_csv(data_path)

    X = df[FEATURES]
    y = df[TARGET]

    # Stratified hold-out for the runnable demo. For production, preserve the
    # report's temporal hold-out and fit preprocessing only on training data.
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y
    )

    candidates = {
        "logistic_regression": LogisticRegression(max_iter=1000, class_weight="balanced"),
        "random_forest": RandomForestClassifier(
            n_estimators=250, random_state=42, class_weight="balanced"
        ),
        "xgboost": XGBClassifier(
            n_estimators=300,
            max_depth=6,
            learning_rate=0.05,
            scale_pos_weight=4.5,
            eval_metric="logloss",
            random_state=42,
        ),
    }

    results = {}
    best_name, best_model, best_score = None, None, -np.inf

    for name, estimator in candidates.items():
        pipe = Pipeline([("preprocessor", build_preprocessor()), ("model", estimator)])
        pipe.fit(X_train, y_train)
        proba = pipe.predict_proba(X_test)[:, 1]
        pred = (proba >= 0.40).astype(int)
        result = metrics(y_test, pred, proba)
        results[name] = result
        if result["recall"] > best_score:
            best_name, best_model, best_score = name, pipe, result["recall"]

    joblib.dump(best_model, ARTIFACTS / "model.joblib")
    (ARTIFACTS / "metrics.json").write_text(
        json.dumps({"selected_model": best_name, "models": results}, indent=2)
    )
    print(json.dumps({"selected_model": best_name, "metrics": results[best_name]}, indent=2))


if __name__ == "__main__":
    main()
