"""Airflow orchestration DAG for the capstone ETL."""
from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.bash import BashOperator

default_args = {
    "owner": "dhl_analytics",
    "depends_on_past": False,
    "start_date": datetime(2026, 1, 1),
    "email_on_failure": False,
    "retries": 2,
    "retry_delay": timedelta(minutes=5),
}

with DAG(
    "dhl_express_etl_pipeline",
    default_args=default_args,
    schedule="0 2 * * *",
    catchup=False,
    tags=["ban6800", "logistics", "etl"],
) as dag:
    ingest = BashOperator(
        task_id="ingest_demo_data",
        bash_command="python -m src.ingestion.generate_demo_data --rows 5500 --output data/raw/shipments.csv",
    )
    transform = BashOperator(
        task_id="privacy_clean_validate",
        bash_command="python -m src.ingestion.etl --input data/raw/shipments.csv --output data/processed/shipments_clean.csv",
    )
    train = BashOperator(
        task_id="train_model",
        bash_command="python -m src.models.train",
    )

    ingest >> transform >> train
