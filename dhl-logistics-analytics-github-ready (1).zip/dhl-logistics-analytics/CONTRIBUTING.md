# Contributing

1. Create a feature branch.
2. Add tests for changes.
3. Run `pytest -q`.
4. Run the ETL and training workflow locally.
5. Open a pull request against `develop` or `main` according to project policy.

Never use unauthorized customer or shipment data in development.
